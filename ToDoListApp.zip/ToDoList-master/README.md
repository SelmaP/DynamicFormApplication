# ToDoList
To Do List Project on Java EE Course , Lecturer : Haim Michael

12.2.2015 - whats new:
* error page works.
* edit items works.
* changed design pattern to front controller.
* added lots of documentation.

***Login Page***

![ToDoList Login](/Ideas/Images/todoLogin.JPG)

***To Do Items List***

![ToDoList Items](/Ideas/Images/todoList.JPG)
